def sum(a,b):
    return a+b

n1=int(input('enter first number: '))
n2=int(input('enter first number: '))
print('sum is: ',sum(n1,n2))
