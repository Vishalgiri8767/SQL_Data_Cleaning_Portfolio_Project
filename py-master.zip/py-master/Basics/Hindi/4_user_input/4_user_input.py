n1=input("Enter first number")
n2=input("Enter second number")
sum=float(n1)+float(n2)
print("Sum is:",sum)