def foo():
    print("In utility.py ==> foo()")

if __name__=='__main__':
    foo()





