def foo():
    bar()

def bar():
    pass

foo()



